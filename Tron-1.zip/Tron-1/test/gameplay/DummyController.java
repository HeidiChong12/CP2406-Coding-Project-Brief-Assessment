/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameplay;

/**
 * Dummy version of Controller class to help with unit testing
 *
 * @author Gabriel
 */
public class DummyController extends Controller {

}
